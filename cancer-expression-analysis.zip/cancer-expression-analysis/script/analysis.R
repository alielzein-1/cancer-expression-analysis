# Installing Packages and loading 
install.packages("tidyverse")
install.packages("ggpubr")
library(tidyverse)
library(ggpubr)

# Loading Dataset
data <- read.csv("tp53_data.csv")
data

# Basic Stats 
data %>%
  group_by(Condition)%>%  
  summarise(mean_expr = mean(TP53_expression),
            sd_expr = sd(TP53_expression))

# T-test 
t_test <- t.test(TP53_expression ~ Condition, data = data)
t_test            


# Visulization of boxplot with jitter and t-test
p <- ggplot(data, aes(x=Condition, y=TP53_expression)) +
      geom_boxplot(fill=c("#00AFBB", "#E7B800"))
      geom_jitter(width=0.1, size=2)
      stat_compare_means(method="t.test", label.y = 7)
      theme_minimal()
      labs(title="TP53 Expression in Tumour vs Normal Tissue", y="TP53 Expression (normalized)")
      
# Show plot 
p

# Saving graph as image
ggsave("tp53_boxplot.png", plot = p, width = 6, height = 4)
